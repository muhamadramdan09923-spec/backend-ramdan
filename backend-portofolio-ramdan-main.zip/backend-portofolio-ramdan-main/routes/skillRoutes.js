'use strict';

const express = require('express');
const router = express.Router();

const ctrl = require('../controllers/projectController');
const { protect, adminOnly } = require('../middlewares/auth');

console.log('CTRL =', ctrl);
console.log('getAllProjects =', typeof ctrl.getAllProjects);
console.log('getProjectById =', typeof ctrl.getProjectById);
console.log('protect =', typeof protect);
console.log('adminOnly =', typeof adminOnly);

// Route PUBLIK
router.get('/', ctrl.getAllProjects);
router.get('/:id', ctrl.getProjectById);

// Route TERPROTEKSI
router.post('/', protect, adminOnly, ctrl.createProject);
router.put('/:id', protect, adminOnly, ctrl.updateProject);
router.delete('/:id', protect, adminOnly, ctrl.deleteProject);

module.exports = router;