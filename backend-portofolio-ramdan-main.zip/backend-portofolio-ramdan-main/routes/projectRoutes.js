'use strict';

const express = require('express');
const router = express.Router();

const ctrl = require('../controllers/projectController');
const { protect, adminOnly } = require('../middlewares/auth');

// ======================
// PUBLIC ROUTES
// ======================
router.get('/', ctrl.getAllProjects);
router.get('/:id', ctrl.getProjectById);

// ======================
// ADMIN ROUTES
// ======================
router.post('/', protect, adminOnly, ctrl.createProject);
router.put('/:id', protect, adminOnly, ctrl.updateProject);
router.delete('/:id', protect, adminOnly, ctrl.deleteProject);

module.exports = router;