'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('projects', {
      id: { allowNull: false, autoIncrement: true, primaryKey: true, type: Sequelize.INTEGER },
      type: { type: Sequelize.INTEGER },
      judul: { type: Sequelize.STRING(255), allowNull: false },
      deskripsi: { type: Sequelize.TEXT },
      teknologi: { type: Sequelize.STRING(255) },
      url_github: { type: Sequelize.STRING(255) },
      url_demo: { type: Sequelize.STRING(255) },
      gambar: { type: Sequelize.STRING(255) },
      createdAt: { allowNull: false, type: Sequelize.DATE },
      updatedAt: { allowNull: false, type: Sequelize.DATE },
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('projects');
  }
};